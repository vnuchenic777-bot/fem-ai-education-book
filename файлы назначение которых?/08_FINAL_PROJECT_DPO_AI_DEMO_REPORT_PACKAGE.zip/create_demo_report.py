from pathlib import Path
import json, textwrap, math
from reportlab.lib import colors
from reportlab.lib.colors import HexColor
from reportlab.lib.enums import TA_LEFT, TA_CENTER, TA_RIGHT
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, PageBreak, Table, TableStyle,
    KeepTogether, Flowable, HRFlowable, ListFlowable, ListItem, Image
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas
from reportlab.pdfbase.pdfmetrics import stringWidth

OUT = Path('/mnt/data')
PDF_PATH = OUT / '08_FINAL_PROJECT_DPO_AI_DEMO_REPORT.pdf'
MD_PATH = OUT / '08_FINAL_PROJECT_DPO_AI_DEMO_REPORT_SOURCE.md'
DATA_PATH = OUT / '08_FINAL_PROJECT_DPO_AI_IMPLEMENTATION_SPEC.json'

# ---------- Fonts ----------
FONT_DIRS = [
    Path('/usr/share/fonts/truetype/dejavu'),
    Path('/usr/share/fonts/truetype/liberation2'),
]
font_regular = None
font_bold = None
for d in FONT_DIRS:
    if (d/'DejaVuSans.ttf').exists():
        font_regular = d/'DejaVuSans.ttf'
        font_bold = d/'DejaVuSans-Bold.ttf'
        break
if not font_regular:
    raise RuntimeError('No suitable font found')
pdfmetrics.registerFont(TTFont('DejaVuSans', str(font_regular)))
pdfmetrics.registerFont(TTFont('DejaVuSans-Bold', str(font_bold)))

# ---------- Data ----------
with open(DATA_PATH, 'r', encoding='utf-8') as f:
    spec = json.load(f)

# ---------- Palette ----------
NAVY = HexColor('#17324D')
BLUE = HexColor('#2F80ED')
LIGHT_BLUE = HexColor('#EAF3FF')
GREEN = HexColor('#219653')
LIGHT_GREEN = HexColor('#EAF8F0')
ORANGE = HexColor('#F2994A')
LIGHT_ORANGE = HexColor('#FFF3E6')
RED = HexColor('#D64545')
LIGHT_RED = HexColor('#FCECEC')
GREY = HexColor('#6B7280')
LIGHT_GREY = HexColor('#F3F4F6')
MID_GREY = HexColor('#D9DEE8')
DARK = HexColor('#111827')
WHITE = colors.white

# ---------- Styles ----------
styles = getSampleStyleSheet()
styles.add(ParagraphStyle(
    name='BaseRus', parent=styles['Normal'], fontName='DejaVuSans', fontSize=9.2,
    leading=12.5, textColor=DARK, spaceAfter=4, alignment=TA_LEFT
))
styles.add(ParagraphStyle(
    name='TitleRus', parent=styles['Title'], fontName='DejaVuSans-Bold', fontSize=21,
    leading=26, textColor=NAVY, alignment=TA_CENTER, spaceAfter=10
))
styles.add(ParagraphStyle(
    name='SubtitleRus', parent=styles['Normal'], fontName='DejaVuSans', fontSize=11.5,
    leading=16, textColor=GREY, alignment=TA_CENTER, spaceAfter=14
))
styles.add(ParagraphStyle(
    name='H1Rus', parent=styles['Heading1'], fontName='DejaVuSans-Bold', fontSize=15,
    leading=19, textColor=NAVY, spaceBefore=8, spaceAfter=8
))
styles.add(ParagraphStyle(
    name='H2Rus', parent=styles['Heading2'], fontName='DejaVuSans-Bold', fontSize=12,
    leading=15, textColor=NAVY, spaceBefore=6, spaceAfter=6
))
styles.add(ParagraphStyle(
    name='SmallRus', parent=styles['Normal'], fontName='DejaVuSans', fontSize=7.6,
    leading=9.8, textColor=DARK, spaceAfter=2
))
styles.add(ParagraphStyle(
    name='SmallCenter', parent=styles['SmallRus'], alignment=TA_CENTER
))
styles.add(ParagraphStyle(
    name='BoxTitle', parent=styles['Normal'], fontName='DejaVuSans-Bold', fontSize=8.5,
    leading=10.5, textColor=NAVY, alignment=TA_CENTER
))
styles.add(ParagraphStyle(
    name='BoxText', parent=styles['Normal'], fontName='DejaVuSans', fontSize=7.2,
    leading=8.8, textColor=DARK, alignment=TA_CENTER
))
styles.add(ParagraphStyle(
    name='Callout', parent=styles['Normal'], fontName='DejaVuSans', fontSize=9,
    leading=12, textColor=DARK, backColor=LIGHT_BLUE, borderColor=BLUE, borderWidth=0.6,
    borderPadding=7, spaceBefore=5, spaceAfter=8
))
styles.add(ParagraphStyle(
    name='QuoteRus', parent=styles['Normal'], fontName='DejaVuSans', fontSize=9,
    leading=12, textColor=DARK, leftIndent=8, rightIndent=8, spaceBefore=5, spaceAfter=8
))

# ---------- Helpers ----------
def P(text, style='BaseRus'):
    return Paragraph(text, styles[style])

def H1(text):
    return Paragraph(text, styles['H1Rus'])

def H2(text):
    return Paragraph(text, styles['H2Rus'])

def bullet_list(items, font_size=9):
    style = styles['BaseRus'] if font_size >= 9 else styles['SmallRus']
    return ListFlowable(
        [ListItem(Paragraph(i, style), leftIndent=10, bulletFontName='DejaVuSans', bulletFontSize=font_size) for i in items],
        bulletType='bullet', start='circle', leftIndent=14, bulletFontName='DejaVuSans', bulletFontSize=font_size
    )

def table_style(header=True, grid=True, header_color=LIGHT_BLUE):
    commands = [
        ('FONTNAME', (0,0), (-1,-1), 'DejaVuSans'),
        ('FONTSIZE', (0,0), (-1,-1), 7.6),
        ('LEADING', (0,0), (-1,-1), 9.2),
        ('VALIGN', (0,0), (-1,-1), 'TOP'),
        ('LEFTPADDING', (0,0), (-1,-1), 5),
        ('RIGHTPADDING', (0,0), (-1,-1), 5),
        ('TOPPADDING', (0,0), (-1,-1), 4),
        ('BOTTOMPADDING', (0,0), (-1,-1), 4),
    ]
    if header:
        commands += [
            ('BACKGROUND', (0,0), (-1,0), header_color),
            ('TEXTCOLOR', (0,0), (-1,0), NAVY),
            ('FONTNAME', (0,0), (-1,0), 'DejaVuSans-Bold'),
        ]
    if grid:
        commands += [('GRID', (0,0), (-1,-1), 0.3, MID_GREY)]
    return TableStyle(commands)

# ---------- Custom Flowables ----------
class RoundedBoxFlowable(Flowable):
    def __init__(self, items, width=170*mm, height=45*mm, cols=3, palette=None, title=None):
        super().__init__()
        self.items = items
        self.width = width
        self.height = height
        self.cols = cols
        self.palette = palette or [LIGHT_BLUE, LIGHT_GREEN, LIGHT_ORANGE, LIGHT_GREY]
        self.title = title
    def wrap(self, availWidth, availHeight):
        self.width = min(self.width, availWidth)
        return self.width, self.height
    def draw(self):
        c = self.canv
        x0, y0 = 0, 0
        rows = math.ceil(len(self.items)/self.cols)
        gap = 7
        box_w = (self.width - gap*(self.cols-1)) / self.cols
        top_space = 18 if self.title else 0
        box_h = (self.height - top_space - gap*(rows-1)) / rows
        if self.title:
            c.setFont('DejaVuSans-Bold', 10)
            c.setFillColor(NAVY)
            c.drawCentredString(self.width/2, self.height-10, self.title)
        for idx,item in enumerate(self.items):
            row = idx // self.cols
            col = idx % self.cols
            x = x0 + col*(box_w+gap)
            y = self.height - top_space - (row+1)*box_h - row*gap
            fill = self.palette[idx % len(self.palette)]
            c.setFillColor(fill)
            c.setStrokeColor(HexColor('#AAB4C3'))
            c.roundRect(x, y, box_w, box_h, 6, fill=1, stroke=1)
            title = item.get('title','')
            text = item.get('text','')
            p1 = Paragraph(title, styles['BoxTitle'])
            p2 = Paragraph(text, styles['BoxText'])
            w1,h1 = p1.wrap(box_w-8, box_h-8)
            w2,h2 = p2.wrap(box_w-8, box_h-10-h1)
            p1.drawOn(c, x+4, y+box_h-5-h1)
            p2.drawOn(c, x+4, y+box_h-9-h1-h2)

class FlowDiagram(Flowable):
    def __init__(self, steps, width=170*mm, height=54*mm, title=None):
        super().__init__()
        self.steps = steps
        self.width = width
        self.height = height
        self.title = title
    def wrap(self, availWidth, availHeight):
        self.width = min(self.width, availWidth)
        return self.width, self.height
    def draw(self):
        c = self.canv
        top_space = 16 if self.title else 0
        if self.title:
            c.setFont('DejaVuSans-Bold', 10)
            c.setFillColor(NAVY)
            c.drawCentredString(self.width/2, self.height-10, self.title)
        n = len(self.steps)
        gap = 9
        arrow_w = 7
        box_w = (self.width - (n-1)*(gap+arrow_w)) / n
        box_h = self.height - top_space - 5
        y = 2
        for i, s in enumerate(self.steps):
            x = i*(box_w+gap+arrow_w)
            fill = s.get('fill', LIGHT_BLUE)
            c.setFillColor(fill)
            c.setStrokeColor(BLUE if i==1 else HexColor('#9BA7B7'))
            c.roundRect(x, y, box_w, box_h, 6, fill=1, stroke=1)
            p1 = Paragraph(s.get('title',''), styles['BoxTitle'])
            p2 = Paragraph(s.get('text',''), styles['BoxText'])
            w1,h1 = p1.wrap(box_w-6, box_h-6)
            w2,h2 = p2.wrap(box_w-6, box_h-6-h1)
            p1.drawOn(c, x+3, y+box_h-5-h1)
            p2.drawOn(c, x+3, y+box_h-9-h1-h2)
            if i < n-1:
                ax = x + box_w + gap/2
                ay = y + box_h/2
                c.setStrokeColor(NAVY)
                c.setFillColor(NAVY)
                c.line(ax, ay, ax+arrow_w, ay)
                c.line(ax+arrow_w, ay, ax+arrow_w-3, ay+3)
                c.line(ax+arrow_w, ay, ax+arrow_w-3, ay-3)

class CycleDiagram(Flowable):
    def __init__(self, steps, width=170*mm, height=90*mm, title=None):
        super().__init__()
        self.steps = steps
        self.width = width
        self.height = height
        self.title = title
    def wrap(self, availWidth, availHeight):
        self.width = min(self.width, availWidth)
        return self.width, self.height
    def draw(self):
        c = self.canv
        if self.title:
            c.setFont('DejaVuSans-Bold', 10)
            c.setFillColor(NAVY)
            c.drawCentredString(self.width/2, self.height-10, self.title)
        cx = self.width/2
        cy = self.height/2 - 5
        rx = self.width*0.36
        ry = self.height*0.30
        bw = 48*mm
        bh = 18*mm
        colors_list = [LIGHT_BLUE, LIGHT_GREEN, LIGHT_ORANGE, LIGHT_GREY, HexColor('#F2F0FF'), LIGHT_RED]
        positions = []
        for i, step in enumerate(self.steps):
            angle = 2*math.pi*i/len(self.steps) - math.pi/2
            x = cx + rx*math.cos(angle) - bw/2
            y = cy + ry*math.sin(angle) - bh/2
            positions.append((x,y))
        # arrows around ellipse
        c.setStrokeColor(HexColor('#8793A6'))
        c.setLineWidth(1)
        for i in range(len(positions)):
            x1,y1 = positions[i]
            x2,y2 = positions[(i+1)%len(positions)]
            c.line(x1+bw/2, y1+bh/2, x2+bw/2, y2+bh/2)
        for i,(x,y) in enumerate(positions):
            c.setFillColor(colors_list[i % len(colors_list)])
            c.setStrokeColor(HexColor('#9BA7B7'))
            c.roundRect(x, y, bw, bh, 6, fill=1, stroke=1)
            p = Paragraph(self.steps[i], styles['BoxTitle'])
            w,h = p.wrap(bw-6, bh-4)
            p.drawOn(c, x+3, y+bh/2-h/2)
        c.setFillColor(NAVY)
        c.setStrokeColor(NAVY)
        c.circle(cx, cy, 18*mm, fill=1, stroke=0)
        p = Paragraph('<font color="white"><b>AI-mandatory</b><br/>задание</font>', styles['SmallCenter'])
        w,h = p.wrap(34*mm, 24*mm)
        p.drawOn(c, cx-17*mm, cy-h/2)

class WorkflowDiagram(Flowable):
    def __init__(self, states, width=170*mm, height=47*mm, title=None):
        super().__init__()
        self.states = states
        self.width = width
        self.height = height
        self.title = title
    def wrap(self, availWidth, availHeight):
        self.width = min(self.width, availWidth)
        return self.width, self.height
    def draw(self):
        c = self.canv
        if self.title:
            c.setFont('DejaVuSans-Bold', 10)
            c.setFillColor(NAVY)
            c.drawCentredString(self.width/2, self.height-10, self.title)
        y = self.height/2 - 10
        n = len(self.states)
        x_start = 12
        x_end = self.width - 12
        step = (x_end - x_start)/(n-1)
        c.setStrokeColor(HexColor('#AAB4C3'))
        c.setLineWidth(2)
        c.line(x_start, y, x_end, y)
        for i, state in enumerate(self.states):
            x = x_start + i*step
            fill = BLUE if i in [2,3,5,7] else LIGHT_GREY
            c.setFillColor(fill)
            c.setStrokeColor(NAVY)
            c.circle(x, y, 5, fill=1, stroke=1)
            p = Paragraph(state, styles['BoxText'])
            w,h = p.wrap(42*mm, 14*mm)
            p.drawOn(c, x-w/2, y-7-h)

class DataModelDiagram(Flowable):
    def __init__(self, width=170*mm, height=74*mm):
        super().__init__()
        self.width = width
        self.height = height
    def wrap(self, availWidth, availHeight):
        self.width = min(self.width, availWidth)
        return self.width, self.height
    def draw_box(self, c, x, y, w, h, title, text, fill):
        c.setFillColor(fill)
        c.setStrokeColor(HexColor('#9BA7B7'))
        c.roundRect(x, y, w, h, 6, fill=1, stroke=1)
        p1 = Paragraph(title, styles['BoxTitle'])
        p2 = Paragraph(text, styles['BoxText'])
        _,h1=p1.wrap(w-6,h-4)
        _,h2=p2.wrap(w-6,h-6-h1)
        p1.drawOn(c,x+3,y+h-4-h1)
        p2.drawOn(c,x+3,y+h-8-h1-h2)
    def arrow(self,c,x1,y1,x2,y2):
        c.setStrokeColor(NAVY)
        c.line(x1,y1,x2,y2)
        # simple arrow head
        ang=math.atan2(y2-y1,x2-x1)
        for da in [2.7,-2.7]:
            c.line(x2,y2,x2-5*math.cos(ang+da),y2-5*math.sin(ang+da))
    def draw(self):
        c=self.canv
        c.setFont('DejaVuSans-Bold',10); c.setFillColor(NAVY); c.drawCentredString(self.width/2,self.height-10,'Связь итогового проекта с платформой')
        w=39*mm; h=15*mm; gap=5*mm
        row1_y=self.height-32*mm
        row2_y=self.height-58*mm
        boxes1=[('CourseTemplate','шаблон курса 72 ч',LIGHT_BLUE),('CourseModule','модуль 8',LIGHT_BLUE),('Lesson','инструкция и шаблон',LIGHT_GREEN),('CourseResource','шаблон, рубрика, чек-лист',LIGHT_GREEN)]
        boxes2=[('AssessmentItem','type = final_project',LIGHT_ORANGE),('SubmissionAttempt','файлы + текст + видео',LIGHT_ORANGE),('AssignmentReview','комментарий, рубрика',LIGHT_RED),('Grade / Enrollment','итоговый статус',LIGHT_RED)]
        coords=[]
        for i,b in enumerate(boxes1):
            x=i*(w+gap)
            self.draw_box(c,x,row1_y,w,h,*b); coords.append((x,row1_y,w,h))
            if i>0: self.arrow(c, coords[i-1][0]+w, row1_y+h/2, x, row1_y+h/2)
        coords2=[]
        for i,b in enumerate(boxes2):
            x=i*(w+gap)
            self.draw_box(c,x,row2_y,w,h,*b); coords2.append((x,row2_y,w,h))
            if i>0: self.arrow(c, coords2[i-1][0]+w, row2_y+h/2, x, row2_y+h/2)
        self.arrow(c, coords[3][0]+w/2, row1_y, coords2[0][0]+w/2, row2_y+h)
        # certificate output
        self.draw_box(c, self.width-50*mm, 4*mm, 50*mm, 13*mm, 'IssuedCertificate', 'после принятия всех компетенций', LIGHT_GREEN)
        self.arrow(c, coords2[3][0]+w, row2_y+h/2, self.width-50*mm, 10*mm)

class ResearchContourDiagram(Flowable):
    def __init__(self, width=170*mm, height=55*mm):
        super().__init__()
        self.width = width
        self.height = height
    def wrap(self, availWidth, availHeight):
        self.width = min(self.width, availWidth)
        return self.width, self.height
    def draw(self):
        c=self.canv
        c.setFont('DejaVuSans-Bold',10); c.setFillColor(NAVY); c.drawCentredString(self.width/2,self.height-10,'Научно-публикационный контур проекта')
        items=[
            ('Методическая ветка','модель итогового проекта'),
            ('Пилот','данные прохождения и доработки'),
            ('Статьи РИНЦ','методика, кейсы, оценивание'),
            ('Статьи ВАК','модель компетенций и доказательств'),
            ('Научный журнал','хроника разработки платформы')
        ]
        n=len(items); gap=7; bw=(self.width-gap*(n-1))/n; bh=24*mm; y=12
        for i,(t,txt) in enumerate(items):
            x=i*(bw+gap)
            fill=[LIGHT_BLUE,LIGHT_GREEN,LIGHT_ORANGE,HexColor('#F2F0FF'),LIGHT_GREY][i]
            c.setFillColor(fill); c.setStrokeColor(HexColor('#9BA7B7')); c.roundRect(x,y,bw,bh,6,fill=1,stroke=1)
            p1=Paragraph(t,styles['BoxTitle']); p2=Paragraph(txt,styles['BoxText'])
            _,h1=p1.wrap(bw-6,bh-4); _,h2=p2.wrap(bw-6,bh-h1-4)
            p1.drawOn(c,x+3,y+bh-4-h1); p2.drawOn(c,x+3,y+bh-8-h1-h2)
            if i<n-1:
                c.setStrokeColor(NAVY); c.line(x+bw,y+bh/2,x+bw+gap,y+bh/2); c.line(x+bw+gap,y+bh/2,x+bw+gap-3,y+bh/2+3); c.line(x+bw+gap,y+bh/2,x+bw+gap-3,y+bh/2-3)

# ---------- Page templates ----------
def draw_header_footer(c, doc):
    c.saveState()
    w,h = A4
    c.setFillColor(NAVY)
    c.rect(0, h-13*mm, w, 13*mm, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont('DejaVuSans-Bold', 8.5)
    c.drawString(16*mm, h-8.5*mm, 'ФЭМ СПБГТИ(ТУ) Образование - демонстрационный отчет')
    c.setFont('DejaVuSans', 8)
    c.drawRightString(w-16*mm, h-8.5*mm, 'Ветка 8. Итоговый проект')
    c.setFillColor(GREY)
    c.setFont('DejaVuSans', 7.5)
    c.drawString(16*mm, 9*mm, 'Проектный документ для внешнего просмотра. Юридические формулировки требуют проверки образовательной организацией.')
    c.drawRightString(w-16*mm, 9*mm, f'стр. {doc.page}')
    c.restoreState()

def draw_cover(c, doc):
    c.saveState()
    w,h=A4
    c.setFillColor(NAVY)
    c.rect(0,0,w,h,fill=1,stroke=0)
    # decorative panels
    c.setFillColor(HexColor('#1E4E79'))
    c.roundRect(20*mm, 214*mm, 170*mm, 30*mm, 10, fill=1, stroke=0)
    c.setFillColor(BLUE)
    c.circle(176*mm, 258*mm, 26*mm, fill=1, stroke=0)
    c.setFillColor(HexColor('#25A67A'))
    c.circle(25*mm, 32*mm, 18*mm, fill=1, stroke=0)
    c.setFillColor(colors.white)
    c.setFont('DejaVuSans-Bold', 17)
    c.drawString(24*mm, 230*mm, 'ФЭМ СПБГТИ(ТУ) Образование')
    c.setFont('DejaVuSans', 10)
    c.drawString(24*mm, 221*mm, 'Демонстрационный отчет по методической разработке')
    c.setFont('DejaVuSans-Bold', 22)
    text='Ветка 8. Итоговый проект курса ДПО по ИИ-инструментам'
    y=178*mm
    max_w=150*mm
    words=text.split()
    lines=[]
    cur=''
    for word in words:
        candidate=(cur+' '+word).strip()
        if stringWidth(candidate, 'DejaVuSans-Bold', 22) <= max_w:
            cur=candidate
        else:
            if cur:
                lines.append(cur)
            cur=word
    if cur:
        lines.append(cur)
    for line in lines:
        c.drawString(24*mm, y, line)
        y-=12*mm
    c.setFont('DejaVuSans', 12)
    sub='От инженерного задания к методическому продукту, платформенной реализации и научно-публикационному контуру'
    y-=8*mm
    max_w=150*mm
    words=sub.split()
    lines=[]
    cur=''
    for word in words:
        candidate=(cur+' '+word).strip()
        if stringWidth(candidate, 'DejaVuSans', 12) <= max_w:
            cur=candidate
        else:
            if cur:
                lines.append(cur)
            cur=word
    if cur:
        lines.append(cur)
    for line in lines:
        c.drawString(24*mm, y, line)
        y-=7*mm
    c.setFillColor(HexColor('#DDEBFF'))
    c.setFont('DejaVuSans', 9)
    c.drawString(24*mm, 36*mm, 'Версия: demo report v0.1   |   Дата: 2026-05-28')
    c.drawString(24*mm, 29*mm, 'Подготовлено для внешнего просмотра, обсуждения и дальнейшего научного оформления')
    c.restoreState()

# ---------- Build content ----------
doc = SimpleDocTemplate(
    str(PDF_PATH), pagesize=A4,
    leftMargin=16*mm, rightMargin=16*mm, topMargin=20*mm, bottomMargin=18*mm,
    title='Демонстрационный отчет - Ветка 8. Итоговый проект ДПО по ИИ',
    author='ФЭМ СПБГТИ(ТУ) Образование'
)

story=[]
# cover placeholder
story.append(Spacer(1, 1*mm))
story.append(PageBreak())

# 1 Executive summary
story.append(H1('1. Назначение демонстрационного отчета'))
story.append(P('Настоящий отчет предназначен для внешнего просмотра: руководителей, методистов, преподавателей, потенциальных участников проекта, разработчиков образовательной платформы и будущих научных соавторов. Документ объясняет, что именно разрабатывается в ветке 8, почему итоговый проект является центральным продуктом курса ДПО и как он связан с образовательной платформой, системой оценивания, компетенциями и будущим научно-публикационным контуром.'))
story.append(P('Отчет не заменяет внутреннее инженерное ТЗ. Его задача - показать общую логику разработки, методический смысл, точку применения в образовательном процессе и перспективу превращения материалов в научные статьи, доклады и отдельный журнал разработки проекта.'))
story.append(Paragraph('<b>Ключевая формулировка:</b> итоговый проект - это не приложение к курсу, а доказательство того, что преподаватель способен перенести ИИ-инструменты в реальную дисциплину, спроектировать задания с обязательным использованием ИИ студентами и подготовить изменения в РПМ.', styles['Callout']))
story.append(FlowDiagram([
    {'title':'Курс ДПО 72 ч','text':'8 модулей, 10 компетенций','fill':LIGHT_BLUE},
    {'title':'Ветка 8','text':'итоговый проект как главный продукт','fill':LIGHT_GREEN},
    {'title':'Артефакты','text':'словарь, задания, занятие, РПМ, риски','fill':LIGHT_ORANGE},
    {'title':'Проверка','text':'рубрика, видео-защита, подтверждение человеком','fill':LIGHT_RED},
    {'title':'Результат','text':'статус, компетенции, документ об обучении','fill':LIGHT_GREY},
], title='Схема 1. Общая логика ветки 8'))
story.append(Spacer(1,4*mm))
story.append(P('В исходной методической базе курс ДПО рассматривается как первая образовательная итерация стратегии факультета по обязательной интеграции ИИ в образовательную деятельность и последующему обновлению РПМ дисциплин.'))
story.append(PageBreak())

# 2 Source base
story.append(H1('2. Исходная база и границы ветки'))
story.append(P('Ветка 8 опирается на уже согласованные проектные документы: структуру курса ДПО, систему оценивания, модель данных платформы, спецификацию MVP, стратегию интеграции ИИ в образовательную деятельность и правовой контур. В данном отчете эти материалы сведены в демонстрационную модель, понятную внешнему наблюдателю.'))
source_rows=[
    ['COURSE_DPO_AI_72H.md','структура 72-часового курса, модули, компетенции ПК-ИИ-1 - ПК-ИИ-10, итоговый проект'],
    ['ASSESSMENT_CERTIFICATION.md','оценивание, двухчастное доказательство компетенций, сертификат'],
    ['DATA_MODEL.md','CourseTemplate, CourseRun, AssessmentItem, AssignmentSubmission, Grade, IssuedCertificate'],
    ['FACULTY_AI_STRATEGY.md','обязательная интеграция ИИ в задания и РПМ дисциплин'],
    ['MVP_SPEC.md','прохождение курса, задания, проверка, прогресс, итоговый статус'],
    ['LEGAL_PRIVACY.md','правовая зона, персональные данные, согласия, необходимость юридической экспертизы'],
]
t=Table([[P('Документ','SmallRus'),P('Роль в ветке 8','SmallRus')]]+[[P(a,'SmallRus'),P(b,'SmallRus')] for a,b in source_rows], colWidths=[52*mm,122*mm])
t.setStyle(table_style(header=True))
story.append(t)
story.append(H2('Границы работ'))
story.append(bullet_list([
    'внутри ветки разрабатываются структура итогового проекта, шаблон для слушателя, критерии, защита и платформенные требования;',
    'не разрабатывается полный текст видеолекций модуля 8;',
    'не утверждается юридический статус сертификата или удостоверения;',
    'не создается публичная витрина, платежный контур или социальная сеть;',
    'юридические формулировки и локальные правила должны проходить проверку в образовательной организации.'
]))
story.append(PageBreak())

# 3 Problem and solution
story.append(H1('3. Методическая проблема и проектное решение'))
story.append(P('Простое обучение преподавателя отдельным ИИ-инструментам не обеспечивает переноса навыка в дисциплину. Преподаватель может научиться пользоваться конкретным сервисом, но не изменить образовательную задачу, критерии оценивания и требования к самостоятельной работе студента. Поэтому итоговый проект строится не как отчет о прохождении курса, а как проект внедрения ИИ в реальную дисциплину.'))
problem_table=[
    ['Проблема','Методическое решение в итоговом проекте'],
    ['Использование ИИ остается бытовым и необязательным','2-3 задания с обязательным использованием ИИ студентами'],
    ['Студент может просто скопировать ответ ИИ','обязательный журнал запросов, итерации, проверка фактов, рефлексия вклада'],
    ['РПМ не отражает новую форму учебной деятельности','предложение по обновлению разделов РПМ и критериев оценивания'],
    ['Оценивание не отличает процесс от результата','рубрика оценивает постановку задачи, работу с ИИ, проверку и авторский вклад'],
    ['Риски данных и авторства остаются неуправляемыми','карта рисков и меры снижения с указанием, что правовые вопросы требуют проверки'],
]
t=Table([[P(x,'SmallRus') for x in row] for row in problem_table], colWidths=[65*mm,109*mm])
t.setStyle(table_style(header=True, header_color=LIGHT_ORANGE))
story.append(t)
story.append(Paragraph('<b>Проектное решение:</b> итоговый проект соединяет методический продукт, процедуру проверки, требования к платформе и научно-публикационный материал. Это делает его центральным узлом курса.', styles['Callout']))
story.append(PageBreak())

# 4 Project structure
story.append(H1('4. Структура итогового проекта слушателя'))
items=[]
for s in spec['learner_project_structure']:
    items.append({'title': f"{s['section_id']}. {s['title']}", 'text': s.get('purpose','')[:140] + ('...' if len(s.get('purpose',''))>140 else '')})
story.append(RoundedBoxFlowable(items, height=92*mm, cols=2, title='Схема 2. Семь обязательных разделов итогового проекта'))
story.append(Spacer(1,4*mm))
story.append(P('Проект состоит из семи разделов: словарь терминологии ИИ применительно к дисциплине; 2-3 задания с обязательным использованием ИИ студентами; план практического или лабораторного занятия; предложение по обновлению РПМ; критерии оценивания студенческих работ; описание рисков и способов их снижения; рефлексия преподавателя о дальнейшем развитии дисциплины.'))
story.append(H2('Функция каждого раздела'))
section_rows=[['Раздел','Что проверяет','Почему важно']]
for s in spec['learner_project_structure']:
    title=s['title']
    purpose=s.get('purpose','')
    why='Связывает проект с профессиональным действием преподавателя.'
    if s['section_id']=='2': why='Фиксирует центральную стратегическую идею - обязательное, проверяемое использование ИИ студентом.'
    if s['section_id']=='4': why='Создает мост между курсом ДПО и официальной методической документацией дисциплины.'
    if s['section_id']=='6': why='Ограничивает риски персональных данных, авторства, недостоверности и поверхностной генерации.'
    section_rows.append([title,purpose,why])
t=Table([[P(x,'SmallRus') for x in row] for row in section_rows], colWidths=[42*mm,72*mm,60*mm])
t.setStyle(table_style(header=True))
story.append(t)
story.append(PageBreak())

# 5 AI mandatory loop
story.append(H1('5. Задание с обязательным использованием ИИ как ядро проекта'))
story.append(P('Задание с обязательным использованием ИИ студентами не является обычным заданием с разрешением использовать ИИ. Оно требует, чтобы ИИ был содержательно необходим для выполнения, а студент демонстрировал управление инструментом: формулировку задачи, запрос, итерации, проверку и собственное решение.'))
story.append(CycleDiagram(['Постановка\nзадачи','Первичный\nзапрос','Итерации\nуточнения','Анализ\nответа','Проверка\nфактов','Исправление\nи вклад'], title='Схема 3. Цикл выполнения AI-mandatory задания'))
story.append(Spacer(1,3*mm))
story.append(H2('Обязательные признаки качественного задания'))
story.append(bullet_list([
    'студент не может получить зачетный результат простым копированием ответа ИИ;',
    'журнал запросов является частью результата, а не факультативным приложением;',
    'фактические утверждения подлежат проверке;',
    'критерии оценивания различают итоговый продукт и процесс работы;',
    'студент объясняет собственный вклад и причины принятых решений.'
]))
story.append(PageBreak())

# 6 Learner path
story.append(H1('6. Путь слушателя от выбора дисциплины до защиты'))
story.append(WorkflowDiagram(['дисциплина','словарь','задания','занятие','РПМ','риски','проект','защита'], title='Схема 4. Методическая траектория слушателя'))
story.append(Spacer(1,6*mm))
steps=[
    ['1','Выбор дисциплины','слушатель выбирает реальную дисциплину, которую ведет или готовит к ведению'],
    ['2','Терминологическая база','формируется словарь ИИ применительно к задачам дисциплины'],
    ['3','Проектирование заданий','создаются 2-3 задания с обязательным использованием ИИ студентами'],
    ['4','План занятия','разрабатывается практическое или лабораторное занятие'],
    ['5','Обновление РПМ','формулируется предложение по изменению рабочей программы модуля'],
    ['6','Риски и рубрика','описываются критерии оценивания и меры снижения рисков'],
    ['7','Видео-защита','слушатель объясняет логику проекта и отвечает на вопросы преподавателя']
]
t=Table([[P('Шаг','SmallRus'),P('Действие','SmallRus'),P('Смысл','SmallRus')]]+[[P(a,'SmallRus'),P(b,'SmallRus'),P(c,'SmallRus')] for a,b,c in steps], colWidths=[14*mm,46*mm,114*mm])
t.setStyle(table_style(header=True, header_color=LIGHT_GREEN))
story.append(t)
story.append(PageBreak())

# 7 Assessment model
story.append(H1('7. Оценивание итогового проекта'))
story.append(P('Оценивание проекта проводится по рубрике на 100 баллов с итоговым решением о зачете. ИИ-помощная проверка может применяться как предварительный анализ, но официальное решение по ДПО подтверждается преподавателем или проверяющим.'))
rubric=spec['assessment_model']['rubric']
rubric_rows=[[P('Код','SmallRus'),P('Критерий','SmallRus'),P('Макс.','SmallRus'),P('Смысл оценки','SmallRus')]]
for r in rubric:
    rubric_rows.append([P(r['criterion_id'],'SmallRus'),P(r['criterion'],'SmallRus'),P(str(r['max_points']),'SmallRus'),P(r['excellent'],'SmallRus')])
t=Table(rubric_rows, colWidths=[16*mm,54*mm,18*mm,86*mm])
t.setStyle(table_style(header=True, header_color=LIGHT_ORANGE))
story.append(t)
story.append(Spacer(1,3*mm))
story.append(Paragraph('<b>Критическое ограничение:</b> проект не может быть зачтен, если отсутствует реальная дисциплина, нет заданий с обязательным использованием ИИ, отсутствуют критерии оценивания или выявлена недопустимая передача персональных/конфиденциальных данных.', styles['Callout']))
story.append(PageBreak())

# 8 Competency map
story.append(H1('8. Связь итогового проекта с компетенциями ПК-ИИ-1 - ПК-ИИ-10'))
story.append(P('Итоговый проект является интеграционным доказательством освоения компетенций. Он непосредственно подтверждает ПК-ИИ-10 и одновременно собирает следы освоения предыдущих компетенций в конкретном профессиональном продукте.'))
cols=['Комп.','Словарь','Запросы','Проверка','Материалы','AI-задания','Риски','Защита']
# manual mapping marks
marks={
'ПК-ИИ-1':[1,0,0,0,0,0,1],'ПК-ИИ-2':[0,1,0,0,1,0,1],'ПК-ИИ-3':[0,0,1,0,1,0,1],
'ПК-ИИ-4':[0,0,0,1,0,0,1],'ПК-ИИ-5':[0,1,1,0,1,0,1],'ПК-ИИ-6':[0,1,1,0,0,0,1],
'ПК-ИИ-7':[0,1,0,1,0,0,1],'ПК-ИИ-8':[0,1,0,1,1,0,1],'ПК-ИИ-9':[0,0,1,0,1,1,1],'ПК-ИИ-10':[1,1,1,1,1,1,1]
}
rows=[[P(c,'SmallCenter') for c in cols]]
for comp in [f'ПК-ИИ-{i}' for i in range(1,11)]:
    rows.append([P(comp,'SmallCenter')]+[P('●' if x else '', 'SmallCenter') for x in marks[comp]])
t=Table(rows, colWidths=[24*mm]+[21.4*mm]*7)
style=table_style(header=True, header_color=LIGHT_BLUE)
# color marked cells
for r in range(1, len(rows)):
    for cidx in range(1, len(cols)):
        if marks[f'ПК-ИИ-{r}'][cidx-1]:
            style.add('BACKGROUND',(cidx,r),(cidx,r), LIGHT_GREEN if r==10 else HexColor('#F5FFF8'))
            style.add('TEXTCOLOR',(cidx,r),(cidx,r), GREEN)
        else:
            style.add('BACKGROUND',(cidx,r),(cidx,r), HexColor('#FAFAFA'))
t.setStyle(style)
story.append(t)
story.append(Spacer(1,3*mm))
story.append(P('Маркер показывает, где в итоговом проекте возникает доказательство соответствующей компетенции. Например, ПК-ИИ-5 подтверждается заданиями с обязательным использованием ИИ, журналом запросов, проверкой результата и защитой логики задания.'))
story.append(PageBreak())

# 9 Video defense
story.append(H1('9. Асинхронная видео-защита'))
vd=spec['video_defense']
story.append(P(f"Формат защиты: {vd['format']}. Рекомендуемая продолжительность: {vd['duration']}. Видео-защита не дублирует письменный проект, а подтверждает, что слушатель понимает логику внедрения, критерии оценивания, риски и ограничения."))
video_rows=[[P('Часть выступления','SmallRus'),P('Время','SmallRus'),P('Проверяемый смысл','SmallRus')]]
meaning=[
    'показывает связь проекта с реальной дисциплиной',
    'объясняет предметный язык ИИ',
    'демонстрирует ядро проекта и защиту от копирования',
    'обосновывает оценивание процесса и результата',
    'показывает безопасность и ограничения',
    'связывает проект с РПМ и дальнейшим внедрением'
]
for p, m in zip(vd['speech_structure'], meaning):
    video_rows.append([P(p['part'], 'SmallRus'), P(p['time'], 'SmallRus'), P(m, 'SmallRus')])
t=Table(video_rows, colWidths=[70*mm,25*mm,79*mm])
t.setStyle(table_style(header=True, header_color=LIGHT_GREEN))
story.append(t)
story.append(H2('Примеры вопросов преподавателя'))
story.append(bullet_list(vd['teacher_questions_bank'][:6], font_size=8))
story.append(PageBreak())

# 10 Workflow
story.append(H1('10. Жизненный цикл итогового проекта в платформе'))
story.append(P('В платформе итоговый проект должен иметь полный жизненный цикл: от черновика до принятия, доработки или отклонения. Все попытки отправки, файлы, комментарии и итоговые оценки должны сохраняться. Это обеспечивает прозрачность проверки и возможность последующего анализа качества курса.'))
story.append(WorkflowDiagram([w['state'] for w in spec['workflow']], title='Схема 5. Состояния итогового проекта в системе'))
story.append(Spacer(1,7*mm))
wf_rows=[[P('Состояние','SmallRus'),P('Описание','SmallRus')]]+[[P(w['state'],'SmallRus'),P(w['description'],'SmallRus')] for w in spec['workflow']]
t=Table(wf_rows, colWidths=[48*mm,126*mm])
t.setStyle(table_style(header=True))
story.append(t)
story.append(PageBreak())

# 11 Platform model
story.append(H1('11. Платформенная реализация'))
story.append(P('Методический итоговый проект должен быть не только текстовым шаблоном, но и объектом образовательной платформы. Он связывается с шаблоном курса, модулем 8, уроком-инструкцией, ресурсами, контрольным элементом, отправками, проверками, оценками, прогрессом и документом об обучении.'))
story.append(DataModelDiagram())
story.append(Spacer(1,5*mm))
story.append(H2('Ключевые сущности'))
entities=[]
for group in ['course_content','assessment','storage']:
    for item in spec['platform_implementation_requirements'].get(group,[]):
        entities.append([item.get('entity',''), item.get('field',''), item.get('value',''), item.get('priority',''), item.get('requirement','')])
# limit to must / major, maybe 12 rows
entities=entities[:13]
t=Table([[P('Сущность','SmallRus'),P('Поле','SmallRus'),P('Значение','SmallRus'),P('Приор.','SmallRus'),P('Требование','SmallRus')]]+[[P(x or '-','SmallRus') for x in row] for row in entities], colWidths=[34*mm,28*mm,32*mm,18*mm,62*mm])
t.setStyle(table_style(header=True, header_color=LIGHT_ORANGE))
story.append(t)
story.append(PageBreak())

# 12 Roles and audit
story.append(H1('12. Роли, доступы и аудит'))
story.append(P('Платформа должна учитывать не только роль пользователя, но и контекст доступа: организацию, курс, запуск курса, группу и назначение проверяющим. Это важно для защиты образовательных данных и корректной проверки итогового проекта.'))
roles = spec['platform_implementation_requirements']['access_control']
role_rows=[[P('Роль','SmallRus'),P('Разрешенные действия','SmallRus')]]
for r in roles:
    role_rows.append([P(r['role'],'SmallRus'),P('<br/>'.join(r['permissions']),'SmallRus')])
t=Table(role_rows, colWidths=[42*mm,132*mm])
t.setStyle(table_style(header=True, header_color=LIGHT_BLUE))
story.append(t)
story.append(H2('События аудита'))
story.append(bullet_list(spec['platform_implementation_requirements']['audit_events'], font_size=8))
story.append(PageBreak())

# 13 Risk contour
story.append(H1('13. Правовой и риск-контур'))
story.append(P('Ветка 8 фиксирует методические риски, но не подменяет юридическую экспертизу. Все вопросы персональных данных, конфиденциальных сведений, авторского права, статуса документа об обучении и локальных правил использования ИИ должны согласовываться с образовательной организацией.'))
risk_rows=[
    ['Риск','Как проявляется','Методическая мера'],
    ['Персональные данные','слушатель или студент переносит данные во внешний ИИ-сервис','запрет без оценки допустимости, чек-лист, обезличивание'],
    ['Поверхностная генерация','итоговый текст создан без понимания и проверки','журнал запросов, итерации, защита логики'],
    ['Непроверенные факты','ИИ формирует уверенный, но ошибочный текст','выделение проверяемых утверждений и ручная проверка'],
    ['Подмена авторства','результат ИИ выдается как самостоятельная работа','декларация использования ИИ и описание вклада'],
    ['Неутвержденный правовой статус','сертификат или правила применения ИИ не согласованы','отдельное согласование с образовательной организацией'],
]
t=Table([[P(x,'SmallRus') for x in row] for row in risk_rows], colWidths=[43*mm,63*mm,68*mm])
t.setStyle(table_style(header=True, header_color=LIGHT_RED))
story.append(t)
story.append(Paragraph('<b>Правило отчета:</b> нормативные требования, номера актов и юридические формулировки не формулируются без официального источника. В демонстрационном отчете указывается только необходимость проверки и согласования.', styles['Callout']))
story.append(PageBreak())

# 14 Scientific contour
story.append(H1('14. Научно-публикационный потенциал'))
story.append(P('Материалы ветки 8 могут стать основой для серии научных публикаций, поскольку они содержат не только описание практики, но и воспроизводимую методическую модель: компетенции, артефакты, критерии, процедуру защиты, цифровую фиксацию результатов и связь с РПМ.'))
story.append(ResearchContourDiagram())
story.append(Spacer(1,5*mm))
story.append(H2('Возможные направления публикаций'))
story.append(bullet_list([
    'компетентностная модель подготовки преподавателей к интеграции ИИ в дисциплины;',
    'методика проектирования заданий с обязательным использованием ИИ студентами;',
    'итоговый проект как доказательство освоения профессиональных компетенций ДПО;',
    'модель оценивания открытых работ с ИИ-помощной проверкой и подтверждением человеком;',
    'цифровая платформа как среда фиксации прогресса, артефактов и документов об обучении;',
    'риски применения ИИ в образовательном процессе и методические способы их снижения.'
]))
story.append(PageBreak())

# 15 Implementation roadmap
story.append(H1('15. Что должно быть реализовано на этапе'))
story.append(P('Для практической реализации ветки 8 нужны две линии работ: методическая и инженерная. Методическая линия готовит содержание, шаблоны и критерии. Инженерная линия реализует итоговый проект как объект платформы.'))
road_rows=[
    ['Блок','Результат','Критерий готовности'],
    ['Методическая структура','описание семи разделов проекта','слушатель понимает, что и в каком формате сдавать'],
    ['Шаблон проекта','заполняемый шаблон итогового проекта','каждый обязательный раздел имеет поля и подсказки'],
    ['Рубрика','100-балльная рубрика и условия зачета','проверяющий может принять, отклонить или отправить на доработку'],
    ['Видео-защита','инструкция, структура, вопросы преподавателя','защита подтверждает авторское понимание проекта'],
    ['Платформа','AssessmentItem final_project, SubmissionAttempt, Review, Grade','все попытки, файлы и решения сохраняются'],
    ['Документ об обучении','связь проекта с финальным статусом и компетенциями','после принятия всех элементов можно формировать основу сертификата']
]
t=Table([[P(x,'SmallRus') for x in row] for row in road_rows], colWidths=[43*mm,66*mm,65*mm])
t.setStyle(table_style(header=True, header_color=LIGHT_GREEN))
story.append(t)
story.append(H2('Определение готовности'))
story.append(bullet_list(spec['definition_of_done'], font_size=8))
story.append(PageBreak())

# 16 Conclusion
story.append(H1('16. Итоговая формулировка ветки'))
story.append(P('Ветка 8 формирует завершенный контур итогового проекта для курса ДПО по ИИ-инструментам. Этот контур одновременно закрывает методическую, оценочную, платформенную и научно-публикационную задачи.'))
story.append(Paragraph('<b>Итог:</b> преподаватель после курса должен не просто владеть набором ИИ-инструментов, а представить применимый проект обновления собственной дисциплины: терминология, задания, занятие, РПМ, критерии, риски, защита и план дальнейшего внедрения.', styles['Callout']))
story.append(H2('Что переносится в будущий единый пакет'))
story.append(bullet_list([
    'методическое описание итогового проекта;',
    'шаблон итогового проекта для слушателя;',
    'рубрика оценивания и критерии зачета;',
    'модель видео-защиты;',
    'описание AI-mandatory заданий;',
    'платформенные требования к хранению, проверке и сертификату;',
    'научно-публикационная карта темы.'
]))
story.append(P('На следующем этапе из данного отчета можно подготовить отдельные материалы: статью о методике итогового проекта, статью о заданиях с обязательным использованием ИИ, статью о платформенной фиксации доказательств компетенций и редакционный план будущего научного журнала разработки.'))

# ---------- Build ----------
doc.build(story, onFirstPage=draw_cover, onLaterPages=draw_header_footer)

# ---------- Markdown companion ----------
md = f"""# Демонстрационный отчет: Ветка 8. Итоговый проект курса ДПО по ИИ-инструментам

PDF: `{PDF_PATH.name}`

Документ предназначен для внешнего просмотра и объясняет:

- назначение ветки 8;
- структуру итогового проекта;
- роль заданий с обязательным использованием ИИ;
- связь с компетенциями ПК-ИИ-1 - ПК-ИИ-10;
- модель оценивания и видео-защиты;
- платформенную реализацию;
- научно-публикационный потенциал.

Основан на файлах: COURSE_DPO_AI_72H.md, ASSESSMENT_CERTIFICATION.md, DATA_MODEL.md, FACULTY_AI_STRATEGY.md, MVP_SPEC.md, LEGAL_PRIVACY.md.
"""
MD_PATH.write_text(md, encoding='utf-8')
print(PDF_PATH)
